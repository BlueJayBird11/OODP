﻿// Name: Ethan Joyce
// Class: CSC 403
// Assignment: Object Oriented Design Patterns
// Date: 10/13/2023

// Description: This program uses the "Chain of Responsibility" design pattern to simulate getting a person to their destination in an airport. If their 
// request is to board the plane, then it is passed through the check-in desk to TSA to the boarding desk which then fufills the request. Otherwise, the
// request is processed accordingly by the previous handlers.

// Abstract base handler
public abstract class Handler
{
    protected Handler Successor;

    public void SetSuccessor(Handler successor)
    {
        Successor = successor;
    }

    public abstract void HandleRequest(string request);
}

// Concrete handlers
public class CheckIn : Handler
{
    public override void HandleRequest(string request)
    {
        if (request == "Check-in")
        {
            Console.WriteLine("Request: " + request + " >> CheckIn handles the request.");
        }
        else if (Successor != null)
        {
            Console.WriteLine("Request: " + request + " >> CheckIn passes the request to TSA.");
            Successor.HandleRequest(request);
        }
    }
}

public class TSA : Handler
{
    public override void HandleRequest(string request)
    {
        if (request == "Security Check")
        {
            Console.WriteLine("Request: " + request + " >> TSA handles the request.");
        }
        else if (Successor != null)
        {
            Console.WriteLine("Request: " + request + " >> TSA passes the request to BoardingDesk.");
            Successor.HandleRequest(request);
        }
    }
}

public class BoardingDesk : Handler
{
    public override void HandleRequest(string request)
    {
        if (request == "Board Plane")
        {
            Console.WriteLine("Request: " + request + " >> BoardingDesk handles the request.");
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        // Create instances of concrete handlers
        Handler handlerA = new CheckIn();
        Handler handlerB = new TSA();
        Handler handlerC = new BoardingDesk();

        // Set up the chain of responsibility
        handlerA.SetSuccessor(handlerB);
        handlerB.SetSuccessor(handlerC);

        // Send requests through the chain
        string[] requests = { "Board Plane", "Check-in", "Security Check" };

        foreach (var request in requests)
        {
            handlerA.HandleRequest(request);
        }
    }
}
