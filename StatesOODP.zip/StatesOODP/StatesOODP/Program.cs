﻿/* 
 * Name: Jay Reich
 * Class: CSC 403 (SoftWare Engineering)
 * Project: Object Oriented Design Patterns
 * Due Date: 10/13/23
 * 
 * Description: This code is intended to show an implamentation of the "State" pattern method. The Game class
 * is the class showing the implamentation. This class has two states, TitleScreen and PlayState These two 
 * states can transition to one another with their options, and thier options will output different things 
 * despite them coming from the same object in the Main function. These classes are subclasses of the abstract
 * class State. This is the specific method this pattern uses, as it avoids making a mess and allows the easy
 * creation of more states.
 */
namespace StateOODP
{
    class Program
    {
        class Game
        {
            // holds the state that the object is in
            private State _state = null;

            public Game(State state)
            {
                this.TransitionStateTo(state);
            }

            // is used to change the _state variable from the State class themselves
            public void TransitionStateTo(State state)
            {
                Console.Write("\n-----------------\n");
                this._state = state;
                this._state.SetGame(this);
            }

            // This function is used to display text that shows what options a state has.
            public void ShowOptions()
            {
                this._state.ShowOptions();
            }

            // For the state "TitleScreen", is the start button that will transition the
            // game to the state "PlayState"
            public void Option1()
            {
                this._state.Option1();
            }

            // For the state "PlayState", is the quit button that will transition the
            // game to the state "TitleScreen"
            public void Option2()
            {
                this._state.Option2();
            }
        }

        // the abstract class that each state is based off of.
        abstract class State
        {
            public Game _game = null;

            public void SetGame(Game game)
            {
                this._game = game;
            }

            public abstract void ShowOptions();
            public abstract void Option1();
            public abstract void Option2();
        }

        class TitleScreen : State
        {
            public override void ShowOptions()
            {
                Console.WriteLine("TitleScreen:\n\tOption 1 - Play\n\tOption 2 - Credits");
            }

            // switches the Game object's state to "PlayState"
            public override void Option1()
            {
                Console.WriteLine("TitleScreen - option 1 - Play");
                Console.WriteLine("\tGame will now transition from TitleScreen to PlayState");
                this._game.TransitionStateTo(new PlayState());
            }

            public override void Option2()
            {
                Console.WriteLine("TitleScreen - option 2 - Credits:\n\tno one.");
            }
        }

        class PlayState : State
        {
            public override void ShowOptions()
            {
                Console.WriteLine("PlayState:\n\tOption 1 - Eat\n\tOption 2 - Quit");
            }
            public override void Option1()
            {
                Console.WriteLine("PlayState - option 1 - Eat");
                Console.WriteLine("\tYou ate a sandwitch.");
            }

            // switches the Game object's state to "TitleScreen"
            public override void Option2()
            {
                Console.WriteLine("PlayState - option 2 - Quit");
                Console.WriteLine("\tGame will now transition from PlayState to TitleScreen");
                this._game.TransitionStateTo(new TitleScreen());
            }
        }

        static void Main(string[] args)
        {
            var game = new Game(new TitleScreen());
            game.ShowOptions();
            game.Option2(); // credits
            game.Option1(); // play - transitions to "PlayState"

            game.ShowOptions();
            game.Option1(); // eat
            game.Option2(); // quit - transitions to "TitleScreen"
        }
    }
}