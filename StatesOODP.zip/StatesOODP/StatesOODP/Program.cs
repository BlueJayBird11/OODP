﻿/* 
 * Name: Jay Reich
 * Class: CSC 403 (SoftWare Engineering)
 * Project: Object Oriented Design Patterns
 * Due Date: 10/13/23
 * 
 * Description: This code is intended to show an implamentation of the "State" pattern method. The Game class
 * is the class showing the implamentation. This class has two states, TitleScreen and PlayState These two 
 * states can transition to one another with their options, and thier options will output different things 
 * despite them coming from the same object in the Main function. These classes are subclasses of the abstract
 * class State. This is the specific method this pattern uses, as it avoids making a mess and allows the easy
 * creation of more states.
 * Most of the relevent code is in the Game.cs file.
 */
using System;

namespace StateOODP
{
    class Program
    {
        static void Main(string[] args)
        {
            var game = new Game(new TitleScreen());
            // tests to make sure that the States are changing
            game.ShowOptions();
            game.Option2(); // credits
            game.MoveFoward();
            game.Option1(); // play - transitions to "PlayState"

            game.ShowOptions();
            game.Option1(); // eat
            game.MoveFoward();
            game.Option2(); // quit - transitions to "TitleScreen"
        }
    }
}