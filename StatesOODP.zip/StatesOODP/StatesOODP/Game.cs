﻿namespace StateOODP
{
    class Game
    {
        // holds the state that the object is in
        private State _state = null;

        public Game(State state)
        {
            this.TransitionStateTo(state);
        }

        // is used to change the _state variable from the State class themselves
        public void TransitionStateTo(State state)
        {
            Console.Write("\n-----------------\n");
            this._state = state;
            this._state.SetGame(this);
        }

        // This function is used to display text that shows what options a state has.
        public void ShowOptions()
        {
            this._state.ShowOptions();
        }

        // For the state "TitleScreen", is the start button that will transition the
        // game to the state "PlayState"
        public void Option1()
        {
            this._state.Option1();
        }

        // For the state "PlayState", is the quit button that will transition the
        // game to the state "TitleScreen"
        public void Option2()
        {
            this._state.Option2();
        }

        // Only does something in State "PlayState"
        public void MoveFoward()
        {
            this._state.MoveFoward();
        }
    }

    // the abstract class that each state is based off of.
    abstract class State
    {
        protected Game _game = null;

        public void SetGame(Game game)
        {
            this._game = game;
        }

        public abstract void ShowOptions();
        public abstract void Option1();
        public abstract void Option2();
        public abstract void MoveFoward();
    }

    class TitleScreen : State
    {
        public override void ShowOptions()
        {
            Console.WriteLine("TitleScreen:\n\tOption 1 - Play\n\tOption 2 - Credits");
        }

        // switches the Game object's state to "PlayState"
        public override void Option1()
        {
            Console.WriteLine("TitleScreen - option 1 - Play");
            Console.WriteLine("\tGame will now transition from TitleScreen to PlayState");
            this._game.TransitionStateTo(new PlayState());
        }

        public override void Option2()
        {
            Console.WriteLine("TitleScreen - option 2 - Credits:\n\tno one.");
        }

        public override void MoveFoward()
        {
            ;
        }
    }

    class PlayState : State
    {
        public override void ShowOptions()
        {
            Console.WriteLine("PlayState:\n\tOption 1 - Eat\n\tOption 2 - Quit\n\tOption 3 - MoveFoward");
        }

        public override void Option1()
        {
            Console.WriteLine("PlayState - option 1 - Eat");
            Console.WriteLine("\tYou ate a sandwitch.");
        }

        // switches the Game object's state to "TitleScreen"
        public override void Option2()
        {
            Console.WriteLine("PlayState - option 2 - Quit");
            Console.WriteLine("\tGame will now transition from PlayState to TitleScreen");
            this._game.TransitionStateTo(new TitleScreen());
        }

        public override void MoveFoward()
        {
            Console.WriteLine("PlayState - option 3 - MoveFoward");
            Console.WriteLine("\tYou took one step foward");
        }
    }
}