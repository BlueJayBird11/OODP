﻿/* 
 * Name: Josiah Norman
 * Class: CSC 403 (SoftWare Engineering)
 * Project: Object Oriented Design Patterns
 * Due Date: 10/13/23
 * 
 * Description: The following code is intended to exemplify the "Strategy" design pattern. In the following program there are two functions both of 
 * which give you the collatz numbers associated with all numbers up to and including your input. The Collatz function is unoptimized for speed. 
 * It will simply run a sequence of operations and give you the associated iteration number for each input. This will not however end up taking any space 
 * The other is the collatz function optimized for space but it creates a hashmap of the input size, so this specific function may pottentially store a 
 * massive amount of information for the trade off of its speed. This expresses "Strategy", although there are two functions they will give the same
 * collatz numbers.
 */
class CollatzSequence
{
    static void Main()
    {
        Console.Write("Enter the value of 'n': ");
        int n = int.Parse(Console.ReadLine());
        Dictionary<long, long> hashMap = new Dictionary<long, long>();

        for (int i = 1; i <= n; i++)
        {
            long collatzValue, operations;

            // Optimized form of Collatz
            (collatzValue, operations) = CollatzOptimized(i, hashMap);

            // General form of Collatz
            // (number, operations) = Collatz(i);

            hashMap[i] = collatzValue;

            // the second part of this print will not match, this is done to show the two functions will commit a differing number of operations
            Console.WriteLine($"Collatz number for {i} is ----> {collatzValue} the number of operations for {i} is ----> {operations}");
        }
    }

    static (long,long) Collatz(long n)
    {
        long count = 0;
        while (n != 1)
        {
            if (n % 2 == 0)
            {
                n /= 2;
            }
            else
            {
                n = 3 * n + 1;
            }
            // by definition the operations must match the count variable thus it is not declared for redundancy sake
            count++; 
        }
        return (count,count);
    }

    static (long, long) CollatzOptimized(long n, Dictionary<long, long> hashMap)
    {
        long count = 0;
        long operations = 0;
        while (n != 1)
        {
            // new peice of code which accounts for the cached values
            if (hashMap.ContainsKey(n))
            {
                operations++;
                return (count + hashMap[n], operations);
            }
            else if (n % 2 == 0)
            {
                n /= 2;
            }
            else
            {
                n = 3 * n + 1;
            }
            operations++;
            count++;
        }
        return (count, operations);
    }
}