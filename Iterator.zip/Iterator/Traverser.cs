﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iterator
{
    internal class Traverser : Iterator
    {
        private int[] _valuesToIterate;
        private int _currentDataIndex;
        public Traverser(DataSet dataSet) {
            _valuesToIterate = dataSet.GetData();
            _currentDataIndex = 0;
        }
        //returns the next data value from the data set
        public int getNext()
        {
            if(hasMore())
            {
                int value = _valuesToIterate[_currentDataIndex];
                _currentDataIndex++;
                Console.WriteLine(value);
                return value;
            }
            Console.WriteLine("No more data values");
            return 0;
        }
        //returns if the data set has anymore values in its structure
        public bool hasMore()
        {
            return _currentDataIndex < _valuesToIterate.Length;
        }
    }
}
