﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iterator
{
    internal class DataSet
    {
        private int[] _data = new int[2];

        public DataSet()
        {
            _data = new int[] { 2, 5 };
        }

        public int[] GetData() { return _data; }
    }
}
