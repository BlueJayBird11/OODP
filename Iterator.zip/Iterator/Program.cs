﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/* 
 * Name: Nathan Jahn
 * Class: CSC 403 (SoftWare Engineering)
 * Project: Object Oriented Design Patterns
 * Due Date: 10/13/23
 * 
 * Description: The following code is being used to represent the "Iterator" design pattern. The Iterator design pattern is used primarily to hide the representation of data.
 * To accomplish this an Iterator interface is created with two functions being getNext() and hasMore() these will traverse the hidden data structure and either return the 
 * next given data value or be able to tell if the structure has reached the end of the data. This pattern is very useful if you had a binary tree for example and did not want
 * to expose that it was inface a binary tree. You would create an DataIterator and have the implementation for the binary tree inside that class. To the outside the only visible
 * functions would be hasMore() and getNext() which tells you nothing about what the underlying structure of how the data is being stored and retrieved.
 */
namespace Iterator
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Very simple showcase of how the iterator design pattern works, creating a data set and traversing through it with the Traverser iterator.
            DataSet dataSet = new DataSet();
            Traverser dataTraverser = new Traverser(dataSet);
            dataTraverser.getNext();
            Console.WriteLine(dataTraverser.hasMore());
            dataTraverser.getNext();
            dataTraverser.getNext();
            Console.WriteLine(dataTraverser.hasMore());
        }
    }
}
