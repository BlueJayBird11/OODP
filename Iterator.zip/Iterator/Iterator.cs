﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iterator
{
    //Iterator interface used to establish abstract functions for deriving classes to add functionality to.
    internal interface Iterator
    {
        int getNext();
        bool hasMore();
    }
}
